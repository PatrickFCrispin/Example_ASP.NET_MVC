﻿using Example_ASP.NET_MVC.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace Example_ASP.NET_MVC.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            var user = new UserViewModel
            {
                Name = "Patrick",
                Email = "patrickfonseca@gmail.com"
            };

            return View(user);
        }

        public IActionResult About()
        {
            var about = new AboutViewModel
            {
                Developer = "Patrick"
            };

            return View(about);
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}