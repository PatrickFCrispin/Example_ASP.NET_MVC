﻿namespace Example_ASP.NET_MVC.Models
{
    public class UserViewModel
    {
        public string? Name { get; set; }
        public string? Email { get; set; }
    }
}