﻿namespace Example_ASP.NET_MVC.Models
{
    public class AboutViewModel
    {
        public string? Developer { get; set; }
        public string GitHubUrl => "https://github.com/PatrickFCrispin";
    }
}